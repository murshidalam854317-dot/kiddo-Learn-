KiddoLearn update MVP
Includes complete A-Z alphabet cards with example words, emojis, and browser speech.
Includes number cards from 1 to 100 with number names and browser speech.
Static PWA prototype; not a native App Store app.
Upload index.html, manifest.json, and README.txt to the root of your GitHub repository.